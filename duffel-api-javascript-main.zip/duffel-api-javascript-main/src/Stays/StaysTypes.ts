import { PaginationMeta } from './../types'

export type StaysBedType = 'single' | 'double' | 'queen' | 'king' | 'sofabed'

export interface StaysBed {
  /**
   * The type of beds available in the room Available types: "single", "double", "queen", "king", "sofabed"
   */
  type: StaysBedType

  /**
   * The number of beds of this type in the room.
   */
  count: number
}

export interface StaysRating {
  // eslint-disable-next-line spellcheck/spell-checker
  /**
   * The source of this rating. Possible values: `"aaa"` (American Automobile Association Diamond Rating), `"northstar"` (Northstar Crown Rating), `"priceline"` (Priceline star rating)
   */
  source: 'aaa' | 'northstar' | 'priceline' | 'bookingcom'

  /**
   * The rating value. This is an integer from 1 to 5 regardless of the `source`.
   */
  value: number
}

export interface StaysRateCondition {
  /**
   * One or more paragraphs that outline the rate condition
   */
  description: string

  /**
   * The condition title
   */
  title: string
}

export interface StaysRateCancellationTimeline {
  /**
   * The amount refundable up until the specified before date
   */
  refund_amount: string

  /**
   * The ISO 8601 datetime for the deadline of a refund.
   */
  before: string

  /**
   * The currency of the amount, as an ISO 4217 currency code.
   */
  currency: string
}

export type StaysLoyaltyProgrammeReference =
  | 'wyndham_rewards'
  | 'choice_privileges'
  | 'marriott_bonvoy'
  | 'best_western_rewards'
  | 'world_of_hyatt'
  | 'hilton_honors'
  | 'ihg_one_rewards'
  | 'leaders_club'
  | 'stash_rewards'
  | 'omni_select_guest'
  | 'i_prefer'
  | 'accor_live_limitless'
  | 'my_6'
  | 'jumeirah_one'
  | 'global_hotel_alliance_discovery'
  | 'duffel_hotel_group_rewards'

export type StaysPaymentMethod = 'balance' | 'card'
export type StaysPaymentType = 'guarantee' | 'deposit' | 'pay_now'
export type StaysSource =
  | 'bookingcom'
  | 'priceline'
  | 'travelport'
  | 'expedia'
  | 'sabre'
  | 'duffel' // Tagged on rates actually sourced via Duffel
  | 'duffel_hotel_group' // Tagged on rates for our test Duffel Hotel.

export interface StaysRate {
  /**
   * The currency of the base_amount, as an ISO 4217 currency code.
   */
  base_amount: string | null

  /**
   * The currency of the base_amount, as an ISO 4217 currency code.
   */
  base_currency: string

  /**
   * The type of boarding offered by this rate.
   */
  board_type:
    | 'room_only'
    | 'breakfast'
    | 'half_board'
    | 'full_board'
    | 'all_inclusive'

  /**
   * A timeline that contains policies, such as possible refunds, once this rate has been booked. This is sorted in ascending chronological order.
   */
  cancellation_timeline: StaysRateCancellationTimeline[]

  /**
   * The conditions or policies that apply to the rate. The information provided should be treated as mandatory and displayed to the traveller during and after the booking process.
   */
  conditions: Array<StaysRateCondition>

  /**
   * Fees are sometimes payable at time of check in. These fees are not collected during the booking process
   */
  due_at_accommodation_amount: string | null

  /**
   * The currency of the due_at_accommodation_amount
   */
  due_at_accommodation_currency: string

  /**
   * ID of a given rate for a accommodation
   */
  id: string

  /**
   * The accepted payment type for this rate.
   * Guarantee rates are paid at at the accommodation.
   * Deposit rates require a prepayment of a deposit amount, then the remainder at the accommodation.
   * Pay now rates require full prepayment.
   * */
  payment_type: StaysPaymentType

  /**
   * The fee amount, as an ISO 4217 currency code.
   */
  fee_amount: string | null

  /**
   * The currency of the fee_amount, as an ISO 4217 currency code
   */
  fee_currency: string

  /**
   * The tax amount, as an ISO 4217 currency code.
   */
  tax_amount: string | null

  /**
   * The currency of the tax_amount, as an ISO 4217 currency code
   */
  tax_currency: string

  /**
   * The total price for the room for all nights and for all occupants. Please note, the occupant may be required to pay fees on arrival at the hotel. These are not included in the total_amount, and are included in due_at_accommodation_amount
   */
  total_amount: string

  /**
   * The currency of the total_amount, as an ISO 4217 currency code
   */
  total_currency: string

  /**
   * The methods available for payment of this rate.

   A rate with the `balance` payment method can be paid for using your Duffel Balance.

   A rate with the `card` payment method can be paid for with card details provided at time of booking.
   */
  available_payment_methods: StaysPaymentMethod[]

  /**
   * The loyalty programme that this rate supports.
   * If the rate does not support a loyalty programme, this will be null.
   * The duffel_hotel_group_rewards value is an example programme for testing and integration purposes, and will only appear on Duffel Hotel Group test hotel rates.
   */
  supported_loyalty_programme: StaysLoyaltyProgrammeReference | null

  /**
   * Whether this rate requires you to be a member of the supported loyalty programme.
   * If true, you must supply a loyalty_programme_account_number when creating a booking for this rate.
   */
  loyalty_programme_required: boolean

  /**
   * The estimated commission amount for this rate.
   */
  estimated_commission_amount: string | null

  /**
   * The currency of the estimated_commission_amount.
   */
  estimated_commission_currency: string | null

  /**
   * The source of the rate.
   * Useful in scenarios where a rate requires explicitly showing the source.
   */
  source: StaysSource

  /**
   * The ISO 8601 date and time at which the rate will expire
   */
  expires_at: string

  /**
   * A rate code is an alphanumeric identifier of specific negotiated pricing and booking conditions.
   * Rate codes are only returned when special contracted rates are available through the hotel provider,
   * distinguishing them from standard public rates.
   */
  code: string | null

  /**
   * The rate description provided by the rate supplier.
   * This typically includes important information about what's included in the rate,
   * such as meal plans, amenities, credits, upgrades, or special benefits.
   * This field is returned exactly as provided by the supplier and is not normalised or
   * standardised across sources.
   * It's intended for internal use or agent review rather than direct display to the guest,
   * as formatting and content quality may vary significantly between suppliers.
   */
  description: string | null

  /**
   * The name of the rate, provided by the rate supplier.
   * This is typically a short, human-readable label that identifies the rate,
   * such as "Best Available Rate" or "Advance Purchase".
   *
   * Example: "Best Available Rate"
   */
  name: string | null

  /**
   * The ID of the negotiated rate (e.g. `nre_…`) that this rate was matched to,
   * when the rate is returned as a result of a negotiated rate passed in the search.
   * Returned when possible at fetch rates, quote and booking.
   */
  negotiated_rate_id?: string | null
}

export interface StaysRoomRate extends StaysRate {
  /**
   * The quantity of rooms available to be booked at this rate. This number is not guaranteed to be accurate. Will be null if this information is unknown.
   */
  quantity_available: number | null
}

export interface StaysPhoto {
  url: string
}

export interface StaysRoom {
  /**
   * The room name.
   */
  name: string

  /**
   * Available beds in the room
   */
  beds?: StaysBed[]

  /**
   * Supplied photos for the room
   */
  photos?: StaysPhoto[]

  /**
   * The available rates for a specific room, including commission, distribution, payment and included services information.
   */
  rates: StaysRoomRate[]
}

export interface StaysAmenity {
  /* the type of amenity */
  type:
    | 'parking'
    | 'gym'
    | 'wifi'
    | '24_hour_front_desk'
    | 'accessibility_hearing'
    | 'accessibility_mobility'
    | 'adult_only'
    | 'business_centre'
    | 'cash_machine'
    | 'childcare_service'
    | 'concierge'
    | 'laundry'
    | 'lounge'
    | 'pets_allowed'
    | 'pool'
    | 'restaurant'
    | 'room_service'
    | 'spa'
  /* label friendly description of the amenity */
  description: string
}

export interface StaysChain {
  /**
   * Duffel ID for this chain
   */
  id: string

  /**
   * The hotel chain's name
   */
  name: string
}

export interface StaysAddress {
  /**
   * The name of the city or metropolitan area where the accommodation is located.
   */
  city_name: string

  /**
   * The ISO 3166-1 alpha-2 code for the country where the hotel is located.
   */
  country_code: string

  /**
   * The first line of the accommodation's address
   */
  line_one: string

  /**
   * The accommodation's postal code (or zip code)
   */
  postal_code: string

  /**
   * The stay's region or state
   */
  region?: string
}

export interface GeographicCoordinates {
  /**
   * The latitude position of the accommodation represented in Decimal degrees  with 6 decimal points with a range between -90° and 90°
   */
  latitude: number

  /**
   * The longitude position of the accommodation represented in Decimal degrees with 6 decimal points with a range between -180° and 180°
   */
  longitude: number
}

export interface StaysLocation {
  /**
   * Address information of the location
   */
  address: StaysAddress

  /**
   * The exact latitude-longitude position of the accommodation. Useful for map views.
   */
  geographic_coordinates: GeographicCoordinates | null
}

export interface StaysAccommodationBrand {
  name: string
  id: string
}

export interface StaysAccommodation {
  /**
   * Duffel ID for this accommodation. Useful for searching availability
   * for the same accommodation via accommodation based search.
   */
  id: string
  /**
   * The amenities available at the accommodation
   */
  amenities: StaysAmenity[] | null

  /**
   * Information about the chain this accommodation belongs to
   */
  chain: StaysChain | null

  brand: StaysAccommodationBrand | null

  /**
   * Check in and check out related information
   */
  check_in_information: {
    /**
     * The ISO 8601 format for the earliest time a traveller can check-in to their room.
     */
    check_out_before_time: string

    /**
     * The ISO 8601 format for the earliest time a traveller can check-out to their room.
     */
    check_in_after_time: string
  } | null

  /**
   * The key collection details for the accommodation.
   */
  key_collection: StaysBookingKeyCollection | null

  /**
   * The accommodation’s description
   */
  description?: string

  /**
   * The accommodation’s email address. Note that this data may differ from the accommodation’s records if it was updated directly by the accommodation after the booking was created.
   */
  email: string | null

  /**
   * Information on the accommodation's location
   */
  location: StaysLocation

  /**
   * The accommodation's name
   */
  name: string

  /**
   * The accommodation's phone number in E.164 (international) format. Note that this data may differ from the accommodation's records if it was updated directly by the accommodation after the booking was created.
   */
  phone_number: string | null

  /**
   * Photos for the accommodation
   */
  photos?: StaysPhoto[]

  /**
   * Ratings of the accommodation
   */
  ratings: StaysRating[] | null

  /**
   * A "star rating" of this accommodation. If available, this is an integer from 1 to 5 "stars". This value is consolidated by Duffel based on data provided by our sources and accommodation providers. For more detailed rating information, see ratings.
   */
  rating: number | null

  /**
   * The number of reviews that contributed to the aggregated review score

   * Example: 336
   */
  review_count: number | null

  /**
   * A review score of this accommodation, aggregated from guest reviews. If available, the value is a score from the 1.0-10.0 range. This value is consolidated by Duffel based on user review data from multiple sources.
   */
  review_score: number | null

  /**
   * Rooms for the accommodation
   */
  rooms: StaysRoom[]

  /**
   * The loyalty programme that this accommodation supports.
   */
  supported_loyalty_programme: StaysLoyaltyProgrammeReference | null
}

export interface StaysAccommodationSuggestion {
  accommodation_id: StaysAccommodation['id']
  accommodation_name: StaysAccommodation['name']
  accommodation_location: StaysLocation
}

/**
 * Represents a quote for a stay.
 */
export interface StaysQuote {
  /**
   * The id of the stay quote.
   *
   * @example: "quo_0000AS0NZdKjjnnHZmSUbI"
   */
  id: string

  /**
   * The ISO 8601 date on which the guest wants to check in.
   * This comes from the search request this quote originates from.
   *
   * Example: "2023-05-24"
   */
  check_in_date: string

  /**
   * The ISO 8601 date on which the guest wants to check out.
   * This comes from the search request this quote originates from.
   *
   * Example: "2023-05-28"
   */
  check_out_date: string

  /**
   * The accommodation associated with this quote.
   */
  accommodation: StaysAccommodation

  /**
   * The total price for the room for all nights and for all guests.
   * Please note, the guest may be required to pay mandatory fees and taxes at the stay.
   * These are not included in the total_amount, and are included in due_at_accommodation_amount.
   *
   * Example: "799.00"
   */
  total_amount: string

  /**
   * The currency of the total_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  total_currency: string

  /**
   * The base amount for this quote, excluding taxes and fees.
   * Will be null if the base amount is unknown.
   *
   * Example: "665.83"
   */
  base_amount: string | null

  /**
   * The currency of the base_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  base_currency: string

  /**
   * The fee amount for this quote.
   * Will be null if the fee amount is unknown.
   *
   * Example: "50.94"
   */
  fee_amount: string | null

  /**
   * The currency of the fee_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  fee_currency: string

  /**
   * The tax amount for this quote.
   * Will be null if the tax amount is unknown.
   *
   * Example: "133.17"
   */
  tax_amount: string | null

  /**
   * The currency of the tax_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  tax_currency: string

  /**
   * Mandatory fees or taxes that are due by the guest at the accommodation.
   * Depending on the accommodation, these may be payable on check-in or check-out.
   * These fees are not collected during the booking process.
   * Will be null if the amount due at accommodation is unknown.
   *
   * Example: "39.95"
   */
  due_at_accommodation_amount: string | null

  /**
   * The currency of the due_at_accommodation_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  due_at_accommodation_currency: string

  /**
   * The portion of total_amount that is payable before check in as deposit for the stay.
   * It may be null if the quote is for a deposit rate but we couldn't get full deposit information —
   * in that case, deposit details are expected to be specified in the rate conditions.
   *
   * Example: "159.80"
   */
  deposit_amount: string | null

  /**
   * The currency of the tax_amount, as an ISO 4217 currency code.
   *
   * Example: "GBP"
   */
  deposit_currency: string

  /**
   * The loyalty programme that this quote supports.
   */
  supported_loyalty_programme: StaysLoyaltyProgrammeReference | null

  /*
   * The number of rooms this quote is for
   */
  rooms: number

  /*
   * A list of guests representing the requested occupancy for this quote
   */

  guests: Array<Guest>
}

export type StaysBookingStatus = 'confirmed' | 'cancelled'

export interface StaysBookingKeyCollection {
  instructions: string
}

export interface StaysBooking {
  /**
   * The ID of the booking
   */
  id: string

  /**
   * The email of the lead guest of the booking
   */
  email: string

  /**
   * The phone number of the lead guest of the booking
   */
  phone_number: string

  /**
   * The accommodation object for the booking
   */
  accommodation: StaysAccommodation

  /**
   * The ISO 8601 date on which the guest wants to check in.
   */
  check_in_date: string

  /**
   * The ISO 8601 date on which the guest wants to check out.
   */
  check_out_date: string

  /**
   * A booking reference for the property you’ll be staying in. This is the reference you should use when contacting the accommodation.
   */
  reference: string | null

  /**
   * The status of the booking. Possible values: requested, confirmed, failed,cancellation_requested,cancellation_confirmed.
   */
  status: StaysBookingStatus

  /**
   * The [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) datetime at which the booking was made.
   */
  confirmed_at: string

  /**
   * The ISO 8601 datetime of the cancellation of this booking.
   * This is null if the booking is not cancelled.
   */
  cancelled_at: string | null

  /**
   * The guests for the booking
   */
  guests: Array<{ given_name: string; family_name: string }>

  /**
   * The loyalty programme that this booking supports.
   */
  supported_loyalty_programme: StaysLoyaltyProgrammeReference | null

  /**
   * Loyalty account number to associate with this booking. Use this only when the quote has a supported_loyalty_programme indicated. Otherwise, this will result into an error.
   */
  loyalty_programme_account_number: string | null

  /**
   * The number of rooms in the booking.
   */
  rooms: number

  /**
   * Metadata pertaining to this booking, generated by the Duffel API.
   */
  metadata: Record<string, string> | null

  /**
   * Deprecated: Instructions to access the accommodation in the booking
   */
  key_collection: StaysBookingKeyCollection | null

  /**
   * The estimated commission amount for this rate.
   */
  estimated_commission_amount: string | null

  /**
   * The currency of the estimated_commission_amount.
   */
  estimated_commission_currency: string | null
}

// Age is not required for adult, but required for child
type Adult = { type: 'adult'; age?: number }
type Child = { type: 'child'; age: number }

export type Guest = Adult | Child

interface CommonStaysSearchParams {
  check_in_date: string
  check_out_date: string
  rooms: number
  guests: Array<Guest>
  mobile?: boolean
  free_cancellation_only?: boolean
  /**
   * Preview: when `true`, only pay-now (Duffel/source) rates; when `false`, only pay-at-property;
   * when `null` or omitted, all rates. See Duffel Stays search API schema.
   */
  instant_payment?: boolean | null

  /**
   * A list of negotiated rate IDs (e.g. `nre_…`) to apply to this search.
   * Any eligible negotiated rates are returned alongside the standard public rates.
   * Matching is best-effort: a supported negotiated rate is not guaranteed to be available.
   */
  negotiated_rate_ids?: string[]
}

export type LocationParams = {
  radius: number
  geographic_coordinates: GeographicCoordinates
}

type LocationSearchParams = {
  location: LocationParams
} & CommonStaysSearchParams

type AccommodationSearchParams = {
  accommodation: {
    ids: Array<string>
    fetch_rates?: boolean
  }
} & CommonStaysSearchParams

export type StaysSearchParams = LocationSearchParams | AccommodationSearchParams

export interface ListAccommodationParams extends PaginationMeta {
  radius?: LocationParams['radius']
  latitude: GeographicCoordinates['latitude']
  longitude: GeographicCoordinates['longitude']
}

export interface StaysSearchResponse {
  results: Array<StaysSearchResult>
  created_at: string
}

export interface StaysSearchResult {
  id: string
  check_in_date: string
  check_out_date: string
  accommodation: StaysAccommodation
  rooms: number
  guests: Array<Guest>
  cheapest_rate_total_amount: string
  cheapest_rate_currency: string
  cheapest_rate_base_amount: string | null
  cheapest_rate_base_currency: string | null
  cheapest_rate_public_amount: string | null
  cheapest_rate_public_currency: string
  cheapest_rate_due_at_accommodation_amount: string | null
  cheapest_rate_due_at_accommodation_currency: string | null
  /**
   * The negotiated rates that were searched for and are supported by this result.
   * A supported negotiated rate does not guarantee that a negotiated rate is available.
   */
  supported_negotiated_rates?: Array<{
    /** The ID of the negotiated rate (e.g. `nre_…`). */
    id: string
    /** The display name of the negotiated rate. */
    display_name: string
  }>
  /**
   * The ISO 8601 date and time at which the search result will expire
   */
  expires_at: string
}

export interface StaysLoyaltyProgramme {
  reference: StaysLoyaltyProgrammeReference
  name: string
  logo_url_svg: string
  logo_url_png_small: string
}

export interface StaysAccommodationReview {
  created_at: string
  reviewer_name: string
  score: number
  text: string
}

export interface StaysAccommodationReviewResponse {
  reviews: Array<StaysAccommodationReview>
}

export type ListParamsBookings = {
  /**
   * Whether to filter bookings matching a given customer user id.
   */
  user_id?: string
}

/**
 * A negotiated rate that enables passing rate access codes for stays accommodation.
 * Can be associated with either a chain or specific accommodations, but not both.
 */
export interface StaysNegotiatedRate {
  /**
   * The ID of the Negotiated Rate
   *
   * Example: "nre_0000AvtkNoC81yBytDM9PE"
   */
  id: string

  /**
   * The rate access code to be utilised when using this negotiated rate
   *
   * Example: "DUFFEL"
   */
  rate_access_code: string

  /**
   * The display name of the negotiated rate
   *
   * Example: "2025 Negotiated Rate"
   */
  display_name: string

  /**
   * Whether this negotiated rate is for live mode. When false, it is for test mode
   *
   * Example: false
   */
  live_mode: boolean

  /**
   * The ID of the hotel chain this negotiated rate is valid for.
   * Mutually exclusive with accommodation_ids.
   *
   * Example: "chn_0000B6QFxO9EOY5cqw5kYK"
   */
  chain_id: string | null

  /**
   * The accommodation ids this negotiated rate is valid for use with.
   * Mutually exclusive with chain_id.
   *
   * Example: ["acc_0000AWr2VsUNIF1Vl91xg0"]
   */
  accommodation_ids: string[] | null
}

/**
 * Payload for creating a negotiated rate associated with a chain.
 * You must provide either chain_id or accommodation_ids, but not both.
 */
export interface StaysNegotiatedRateCreatePayloadWithChain {
  /**
   * The rate access code to be utilised when using this negotiated rate
   *
   * Example: "DUFFEL"
   */
  rate_access_code: string

  /**
   * The display name of the negotiated rate
   *
   * Example: "2025 Negotiated Rate"
   */
  display_name: string

  /**
   * The ID of the hotel chain this negotiated rate is valid for
   *
   * Example: "chn_0000B6QFxO9EOY5cqw5kYK"
   */
  chain_id: string
}

/**
 * Payload for creating a negotiated rate associated with accommodations.
 * You must provide either chain_id or accommodation_ids, but not both.
 */
export interface StaysNegotiatedRateCreatePayloadWithAccommodations {
  /**
   * The rate access code to be utilised when using this negotiated rate
   *
   * Example: "DUFFEL"
   */
  rate_access_code: string

  /**
   * The display name of the negotiated rate
   *
   * Example: "2025 Negotiated Rate"
   */
  display_name: string

  /**
   * The accommodation ids this negotiated rate is valid for use with
   *
   * Example: ["acc_0000AWr2VsUNIF1Vl91xg0"]
   */
  accommodation_ids: string[]
}

/**
 * Payload for creating a negotiated rate.
 * You must provide either chain_id or accommodation_ids, but not both.
 */
export type StaysNegotiatedRateCreatePayload =
  | StaysNegotiatedRateCreatePayloadWithChain
  | StaysNegotiatedRateCreatePayloadWithAccommodations

/**
 * Payload for updating a negotiated rate.
 * You can update the display_name and change the association to chain_id or accommodation_ids.
 * If updating the association, you must provide only one of chain_id or accommodation_ids.
 */
export interface StaysNegotiatedRateUpdatePayload {
  /**
   * The display name of the negotiated rate
   *
   * Example: "2025 Negotiated Rate"
   */
  display_name?: string

  /**
   * The ID of the hotel chain this negotiated rate is valid for.
   * Setting this will remove any existing accommodation_ids association.
   *
   * Example: "chn_0000B6QFxO9EOY5cqw5kYK"
   */
  chain_id?: string

  /**
   * The accommodation ids this negotiated rate is valid for use with.
   * Setting this will remove any existing chain_id association.
   *
   * Example: ["acc_0000AWr2VsUNIF1Vl91xg0"]
   */
  accommodation_ids?: string[]
}
